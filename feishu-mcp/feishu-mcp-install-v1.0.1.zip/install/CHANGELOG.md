# 更新日志 v1.0.0 (2026-01-20)

## ✨ 新功能

### 1. 自动权限修复
- ✅ `install.sh` 现在会自动检测并修复所有脚本的执行权限
- ✅ 无需手动运行 `chmod +x`
- ✅ 适用于所有相关脚本（install.sh, verify-install.sh, diagnose.sh, quick-setup.sh）

### 2. 安装包装器脚本
- ✅ 新增 `install_wrapper.sh` 作为友好的入口点
- ✅ 自动修复所有脚本权限
- ✅ 提供清晰的进度提示

### 3. 诊断工具
- ✅ 新增 `diagnose.sh` 全面诊断脚本
- ✅ 检查配置文件位置和内容
- ✅ 验证 Node.js 环境
- ✅ 测试 feishu-mcp 包
- ✅ 检查 Claude Desktop 进程

### 4. CLI vs Desktop 说明文档
- ✅ 新增 `CLI_VS_DESKTOP.md` 详细说明
- ✅ 解释两者区别和使用场景
- ✅ 提供正确的验证方法

## 📝 文档改进

### 安装文档 (`安装文档.md` / `INSTALL_GUIDE.md`)
- ✅ 添加三种安装方法（包装器/直接/传统）
- ✅ 强调推荐使用 `bash` 命令运行
- ✅ 改进权限问题的解决方案

### 快速参考 (`快速参考.md`)
- ✅ 更新安装命令说明
- ✅ 提供多种安装选项
- ✅ 标注推荐方法

## 🔧 技术改进

### install.sh
**新增功能**：
```bash
fix_script_permissions() {
    # 自动检测并修复所有脚本权限
}
```

**工作原理**：
- 在脚本启动时自动执行
- 检测脚本目录下的所有 .sh 文件
- 如果缺少执行权限，自动添加

### install_wrapper.sh
**主要功能**：
- 作为用户友好的入口点
- 批量修复所有脚本权限
- 显示清晰的进度信息
- 最后调用 install.sh

## 🎯 用户体验改进

### 改进前
```bash
cd install
./diagnose.sh
# ❌ zsh: permission denied: ./diagnose.sh
```

### 改进后

**方法 1（最简单）**：
```bash
cd install
bash install_wrapper.sh
# ✅ 自动修复所有权限并安装
```

**方法 2**：
```bash
cd install
bash install.sh
# ✅ 直接运行，无需权限
```

**方法 3**：
```bash
cd install
./install.sh
# ✅ 脚本会自动修复自己的权限
```

## 📦 安装包信息

- **文件名**: `feishu-mcp-install-v1.0.0.zip`
- **大小**: **26 KB**（从 24 KB 增加）
- **新增文件**: 2 个
  - `install_wrapper.sh` - 包装器脚本
  - `CLI_VS_DESKTOP.md` - 说明文档

## 🐛 修复的问题

1. **权限问题** ✅
   - 用户不再需要手动运行 `chmod +x`
   - 脚本会自动修复权限

2. **用户困惑** ✅
   - 添加 `CLI_VS_DESKTOP.md` 说明文档
   - 明确说明 `claude mcp list` 和 Claude Desktop 的区别

3. **诊断困难** ✅
   - 提供 `diagnose.sh` 全面诊断工具
   - 提供清晰的故障排查步骤

## 📊 改进效果对比

| 项目 | 改进前 | 改进后 |
|------|--------|--------|
| 安装方式 | 1 种 | 3 种选择 ✅ |
| 权限问题 | 需手动修复 | 自动修复 ✅ |
| 诊断工具 | 仅 verify-install | diagnose + CLI_VS_DESKTOP ✅ |
| 文档说明 | 基础 | 详细+示例 ✅ |
| 用户体验 | 中等 | 优秀 ✅ |

## 🔜 未来计划

1. 添加更多语言支持
2. 图形化安装界面
3. 自动更新检查
4. 一键卸载功能
5. 配置向导增强

## 📞 技术支持

遇到问题？

1. 运行 `bash diagnose.sh` 诊断问题
2. 查看 `CLI_VS_DESKTOP.md` 了解区别
3. 阅读 `FAQ.md` 常见问题
4. 查看 `INSTALL_GUIDE.md` 详细说明

---

**版本**: v1.0.0
**发布日期**: 2026-01-20
**兼容性**: macOS, Node.js >= v18.0.0
