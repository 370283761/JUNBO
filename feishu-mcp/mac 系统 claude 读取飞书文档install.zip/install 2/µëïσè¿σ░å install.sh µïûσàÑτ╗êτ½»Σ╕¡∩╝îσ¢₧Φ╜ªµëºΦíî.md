# 飞书 MCP Server 安装文档

## 📦 安装包信息

**文件名**: feishu-mcp-install-v1.0.0.zip
**大小**: 17 KB
**系统**: macOS
**需要**: Node.js >= v18.0.0

## 🚀 快速安装（3步）

### 步骤 1：解压文件

双击 `feishu-mcp-install-v1.0.0.zip` 解压。

### 步骤 2：运行安装脚本

打开终端，执行：

```bash
cd install
./install.sh
```

可以手动将 install.sh 拖入终端中，回车执行；


等待提示"安装成功"。

### 步骤 3：重启 Claude Desktop

1. 按 `Cmd+Q` 完全退出 Claude Desktop
2. 等待 3 秒
3. 重新启动 Claude Desktop

✅ **安装完成！**

## 🧪 测试功能

在 Claude Desktop 对话框中输入：

```
请读取这个飞书文档：
https://gz-junbo.feishu.cn/wiki/WsWowfLJoiiQKkk7RQOcMuewnlg
```

**首次使用时**，选择：`Yes, and don't ask again`

如果 Claude 成功读取并返回文档内容，说明配置成功！

## ❓ 常见问题

### Q: 如何打开终端？

**A**: 按 `Cmd+空格`，输入"终端"或"Terminal"，按回车。

### Q: 提示"Permission denied"？

**A**: 运行以下命令后重试：

```bash
chmod +x install.sh
./install.sh
```

### Q: MCP Server 未运行？

**A**:
1. 打开 Claude Desktop
2. Settings > Developer
3. 检查 "feishu" 是否显示绿色

如果显示红色，查看 "View Logs" 中的错误信息。

### Q: 无法读取文档？

**A**:
1. 在飞书中打开文档
2. 点击右上角 `...` > `添加应用`
3. 搜索并添加应用
4. 重试读取

## 📚 使用示例

### 读取文档

```
请读取并总结这个飞书文档
```

### 格式转换

```
将这个飞书文档转换为 Markdown 格式
```

### 内容分析

```
分析这个文档的结构和主要内容
```

## 🔧 验证安装

运行验证脚本：

```bash
./verify-install.sh
```

应该看到所有检查项显示 `✓ 通过`。

## 🆘 需要帮助？

- 查看 `FAQ.md` - 详细的常见问题
- 查看 `USAGE_GUIDE.md` - 使用指南
- 运行 `./verify-install.sh` - 诊断问题

## 🔄 卸载

删除配置文件：

```bash
rm ~/Library/Application\ Support/Claude/claude_desktop_config.json
```

然后重启 Claude Desktop。

---

**版本**: v1.0.0
**更新**: 2026-01-20
**支持**: 查看 FAQ.md
